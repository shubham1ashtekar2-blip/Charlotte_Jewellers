// Basic client-side helpers
function addToCart(productId, qty=1) {
  fetch(`/cart/add/${productId}`, {method: 'POST'})
    .then(r => r.json())
    .then(d => {
      const badge = document.querySelector('#cart-count');
      if (badge) badge.textContent = d.cart_count;
    });
}