# Charlotte Jewellers – Full-Stack Web App (Flask + SQLite)

This is a fully functional sample e‑commerce site for **Charlotte Jewellers** with two separate portals:

- **Customer Portal**: Browse products, search, view product details, add to cart, checkout (demo), manage profile, and view orders.
- **Admin Portal**: Dashboard, manage products (CRUD), manage categories, view/update orders, and list customers.

---

## Tech Stack
- Backend: **Flask**, **Flask-Login**, **Flask-SQLAlchemy**
- Database: **SQLite** (file-based)
- Frontend: HTML5, **Bootstrap 5** (via CDN), Vanilla JS

## Features
- User registration & login with password hashing
- Role-based access (admin vs. customer)
- Product catalog, categories, search
- Product pages with images
- Session cart; checkout with mock payment methods (Card / Cash on Delivery)
- Orders & order items
- Admin product/category CRUD
- Admin orders view & status update (Processing, Shipped, Completed, Cancelled)
- Configurable currency symbol (default **C$**) and store name

---

## Local Setup

1. **Create a virtual environment (recommended)**
   ```bash
   cd Charlotte_Jewellers
   python -m venv .venv
   source .venv/bin/activate  # Windows: .venv\Scripts\activate
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Initialize the database and seed sample data**
   ```bash
   python init_db.py
   ```
   This creates `app.db`, an admin user, categories, and sample products.

   **Admin login (default):**
   - Email: `admin@charlottejewellers.com`
   - Password: `admin123` (change it after first login under Admin → Settings)

4. **Run the app**
   ```bash
   flask --app app run --debug
   ```
   Visit: http://127.0.0.1:5000/

---

## Configuration
Set environment variables (optional, sensible defaults provided):
```bash
export SECRET_KEY="change-this-in-production"
export STORE_NAME="Charlotte Jewellers"
export CURRENCY_SYMBOL="C$"
```

---

## Project Structure
```
Charlotte_Jewellers/
├── app.py
├── init_db.py
├── requirements.txt
├── README.md
├── app.db (generated after init)
├── static/
│   ├── css/style.css
│   ├── js/app.js
│   └── images/ (sample placeholders)
└── templates/
    ├── base.html
    ├── index.html
    ├── catalog.html
    ├── product_detail.html
    ├── cart.html
    ├── checkout.html
    ├── order_success.html
    ├── login.html
    ├── register.html
    ├── profile.html
    └── admin/
        ├── layout.html
        ├── dashboard.html
        ├── products.html
        ├── product_form.html
        ├── categories.html
        ├── category_form.html
        ├── orders.html
        ├── customers.html
        └── settings.html
```

---

## Notes
- This is a demo app. For production, add CSRF protection, input validation, image upload handling, and real payments. Place behind HTTPS and rotate secrets.
- All prices are stored as **integer cents** to avoid floating point precision issues.
- Images use placeholder URLs; you can replace them in Admin → Products.

---

## License
MIT – Use, modify, and adapt freely.