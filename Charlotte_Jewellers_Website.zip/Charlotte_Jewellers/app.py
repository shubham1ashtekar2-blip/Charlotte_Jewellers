import os
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, current_user, login_required, UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

# --- App & Config ---
app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-change-me')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['STORE_NAME'] = os.getenv('STORE_NAME', 'Charlotte Jewellers')
app.config['CURRENCY_SYMBOL'] = os.getenv('CURRENCY_SYMBOL', 'C$')

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# --- Models ---
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    orders = db.relationship('Order', backref='user', lazy=True)

    def set_password(self, pw):
        self.password_hash = generate_password_hash(pw)

    def check_password(self, pw):
        return check_password_hash(self.password_hash, pw)

class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    products = db.relationship('Product', backref='category', lazy=True)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, default='')
    price_cents = db.Column(db.Integer, nullable=False)
    stock = db.Column(db.Integer, default=0)
    image_url = db.Column(db.String(500), default='')
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'), nullable=True)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    customer_name = db.Column(db.String(200), nullable=False)
    customer_email = db.Column(db.String(200), nullable=False)
    address = db.Column(db.String(300), nullable=False)
    status = db.Column(db.String(50), default='Processing')
    total_cents = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    items = db.relationship('OrderItem', backref='order', lazy=True, cascade='all, delete-orphan')

class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    product = db.relationship('Product')
    quantity = db.Column(db.Integer, nullable=False)
    unit_price_cents = db.Column(db.Integer, nullable=False)

# --- Login ---
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# --- Helpers ---
def get_cart():
    return session.get('cart', {})

def save_cart(cart):
    session['cart'] = cart
    session.modified = True

def cart_items():
    cart = get_cart()
    items = []
    total = 0
    for str_pid, entry in cart.items():
        product = Product.query.get(int(str_pid))
        if not product:
            continue
        qty = entry.get('qty', 1)
        subtotal = product.price_cents * qty
        total += subtotal
        items.append({'product': product, 'qty': qty, 'subtotal': subtotal})
    return items, total

def admin_required(func):
    from functools import wraps
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('Admin access required', 'warning')
            return redirect(url_for('login'))
        return func(*args, **kwargs)
    return wrapper

# --- Routes: Storefront ---
@app.context_processor
def inject_now_and_config():
    from datetime import datetime as _dt
    return {'now': _dt.utcnow, 'config': app.config}

@app.route('/')
def home():
    products = Product.query.order_by(Product.id.desc()).limit(8).all()
    return render_template('index.html', products=products)

@app.route('/catalog')
def catalog():
    q = request.args.get('q', '').strip()
    category_id = request.args.get('category')
    query = Product.query
    if q:
        like = f"%{q}%"
        query = query.filter(Product.name.ilike(like))
    if category_id:
        query = query.filter(Product.category_id==int(category_id))
    products = query.order_by(Product.id.desc()).all()
    categories = Category.query.order_by(Category.name.asc()).all()
    return render_template('catalog.html', products=products, categories=categories)

@app.route('/product/<int:pid>')
def product_detail(pid):
    product = Product.query.get_or_404(pid)
    return render_template('product_detail.html', product=product)

@app.post('/cart/add/<int:pid>')
def cart_add(pid):
    Product.query.get_or_404(pid)
    cart = get_cart()
    key = str(pid)
    entry = cart.get(key, {'qty': 0})
    entry['qty'] += 1
    cart[key] = entry
    save_cart(cart)
    count = sum([e['qty'] for e in cart.values()])
    if request.headers.get('accept') == 'application/json':
        return jsonify({'ok': True, 'cart_count': count})
    flash('Added to cart', 'success')
    return redirect(request.referrer or url_for('catalog'))

@app.post('/cart/remove/<int:pid>')
def cart_remove(pid):
    cart = get_cart()
    cart.pop(str(pid), None)
    save_cart(cart)
    flash('Removed from cart', 'info')
    return redirect(url_for('view_cart'))

@app.route('/cart')
def view_cart():
    items, total = cart_items()
    return render_template('cart.html', items=items, total=total)

@app.route('/checkout', methods=['GET','POST'])
def checkout():
    items, total = cart_items()
    if request.method == 'POST':
        if not items:
            flash('Your cart is empty', 'warning')
            return redirect(url_for('catalog'))
        name = request.form['name']
        email = request.form['email']
        address = request.form['address']
        order = Order(
            user_id=current_user.id if current_user.is_authenticated else None,
            customer_name=name,
            customer_email=email,
            address=address,
            status='Processing',
            total_cents=total,
        )
        db.session.add(order)
        db.session.flush()
        for it in items:
            db.session.add(OrderItem(
                order_id=order.id,
                product_id=it['product'].id,
                quantity=it['qty'],
                unit_price_cents=it['product'].price_cents
            ))
            # Reduce stock (not below zero)
            it['product'].stock = max(0, it['product'].stock - it['qty'])
        db.session.commit()
        # clear cart
        save_cart({})
        return redirect(url_for('order_success', oid=order.id))
    return render_template('checkout.html', items=items, total=total)

@app.route('/order/success/<int:oid>')
def order_success(oid):
    order = Order.query.get_or_404(oid)
    return render_template('order_success.html', order=order)

# --- Auth ---
@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form['email'].strip().lower()
        pw = request.form['password']
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(pw):
            login_user(user)
            flash('Welcome back!', 'success')
            next_url = request.args.get('next')
            return redirect(next_url or url_for('home'))
        flash('Invalid credentials', 'danger')
    return render_template('login.html')

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email'].strip().lower()
        pw = request.form['password']
        if User.query.filter_by(email=email).first():
            flash('Email already in use', 'warning')
            return redirect(url_for('register'))
        user = User(name=name, email=email)
        user.set_password(pw)
        db.session.add(user)
        db.session.commit()
        login_user(user)
        flash('Account created', 'success')
        return redirect(url_for('home'))
    return render_template('register.html')

@app.route('/logout')
def logout():
    logout_user()
    flash('Logged out', 'info')
    return redirect(url_for('home'))

@app.route('/profile')
@login_required
def profile():
    orders = Order.query.filter_by(user_id=current_user.id).order_by(Order.created_at.desc()).all()
    return render_template('profile.html', orders=orders)

# --- Admin ---
@app.route('/admin')
@login_required
@admin_required
def admin_index():
    counts = {
        'products': Product.query.count(),
        'orders': Order.query.count(),
        'customers': User.query.filter_by(is_admin=False).count(),
    }
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(5).all()
    return render_template('admin/dashboard.html', counts=counts, recent_orders=recent_orders)

# Products
@app.route('/admin/products')
@login_required
@admin_required
def admin_products():
    products = Product.query.order_by(Product.id.desc()).all()
    return render_template('admin/products.html', products=products)

@app.route('/admin/products/new', methods=['GET','POST'])
@login_required
@admin_required
def admin_product_new():
    categories = Category.query.order_by(Category.name.asc()).all()
    if request.method == 'POST':
        name = request.form['name']
        price = float(request.form['price'])
        stock = int(request.form['stock'])
        image_url = request.form.get('image_url','')
        description = request.form.get('description','')
        category_id = request.form.get('category_id') or None
        p = Product(name=name, price_cents=int(round(price*100)), stock=stock, image_url=image_url, description=description,
                    category_id=int(category_id) if category_id else None)
        db.session.add(p)
        db.session.commit()
        flash('Product created', 'success')
        return redirect(url_for('admin_products'))
    return render_template('admin/product_form.html', product=None, categories=categories)

@app.route('/admin/products/<int:pid>/edit', methods=['GET','POST'])
@login_required
@admin_required
def admin_product_edit(pid):
    product = Product.query.get_or_404(pid)
    categories = Category.query.order_by(Category.name.asc()).all()
    if request.method == 'POST':
        product.name = request.form['name']
        product.price_cents = int(round(float(request.form['price'])*100))
        product.stock = int(request.form['stock'])
        product.image_url = request.form.get('image_url','')
        product.description = request.form.get('description','')
        category_id = request.form.get('category_id') or None
        product.category_id = int(category_id) if category_id else None
        db.session.commit()
        flash('Product updated', 'success')
        return redirect(url_for('admin_products'))
    return render_template('admin/product_form.html', product=product, categories=categories)

@app.post('/admin/products/<int:pid>/delete')
@login_required
@admin_required
def admin_product_delete(pid):
    product = Product.query.get_or_404(pid)
    db.session.delete(product)
    db.session.commit()
    flash('Product deleted', 'info')
    return redirect(url_for('admin_products'))

# Categories
@app.route('/admin/categories')
@login_required
@admin_required
def admin_categories():
    categories = Category.query.order_by(Category.name.asc()).all()
    return render_template('admin/categories.html', categories=categories)

@app.route('/admin/categories/new', methods=['GET','POST'])
@login_required
@admin_required
def admin_category_new():
    if request.method == 'POST':
        name = request.form['name']
        if Category.query.filter_by(name=name).first():
            flash('Category already exists', 'warning')
            return redirect(url_for('admin_categories'))
        db.session.add(Category(name=name))
        db.session.commit()
        flash('Category created', 'success')
        return redirect(url_for('admin_categories'))
    return render_template('admin/category_form.html', category=None)

@app.route('/admin/categories/<int:cid>/edit', methods=['GET','POST'])
@login_required
@admin_required
def admin_category_edit(cid):
    category = Category.query.get_or_404(cid)
    if request.method == 'POST':
        category.name = request.form['name']
        db.session.commit()
        flash('Category updated', 'success')
        return redirect(url_for('admin_categories'))
    return render_template('admin/category_form.html', category=category)

@app.post('/admin/categories/<int:cid>/delete')
@login_required
@admin_required
def admin_category_delete(cid):
    category = Category.query.get_or_404(cid)
    db.session.delete(category)
    db.session.commit()
    flash('Category deleted', 'info')
    return redirect(url_for('admin_categories'))

# Orders
@app.route('/admin/orders')
@login_required
@admin_required
def admin_orders():
    orders = Order.query.order_by(Order.created_at.desc()).all()
    return render_template('admin/orders.html', orders=orders)

@app.post('/admin/orders/<int:oid>/status')
@login_required
@admin_required
def admin_order_status(oid):
    order = Order.query.get_or_404(oid)
    order.status = request.form['status']
    db.session.commit()
    flash('Order status updated', 'success')
    return redirect(url_for('admin_orders'))

# Customers
@app.route('/admin/customers')
@login_required
@admin_required
def admin_customers():
    customers = User.query.filter_by(is_admin=False).order_by(User.created_at.desc()).all()
    return render_template('admin/customers.html', customers=customers)

# Settings
@app.route('/admin/settings', methods=['GET','POST'])
@login_required
@admin_required
def admin_settings():
    if request.method == 'POST':
        app.config['STORE_NAME'] = request.form.get('store_name') or app.config['STORE_NAME']
        app.config['CURRENCY_SYMBOL'] = request.form.get('currency_symbol') or app.config['CURRENCY_SYMBOL']
        new_pw = request.form.get('admin_password')
        if new_pw:
            current_user.set_password(new_pw)
            db.session.commit()
            flash('Admin password updated', 'success')
        flash('Settings saved (in-memory). Set env vars for persistence.', 'info')
    return render_template('admin/settings.html')

if __name__ == '__main__':
    app.run(debug=True)