from app import db, User, Category, Product

def run():
    db.drop_all()
    db.create_all()

    # Admin user
    admin = User(name='Store Admin', email='admin@charlottejewellers.com', is_admin=True)
    admin.set_password('admin123')
    db.session.add(admin)

    # Categories
    rings = Category(name='Rings')
    necklaces = Category(name='Necklaces')
    earrings = Category(name='Earrings')
    bracelets = Category(name='Bracelets')
    db.session.add_all([rings, necklaces, earrings, bracelets])
    db.session.flush()

    # Products (sample)
    products = [
        Product(name='Classic Diamond Ring', description='Timeless diamond solitaire in white gold.',
                price_cents=129999, stock=10, image_url='https://images.unsplash.com/photo-1520962910508-48507b3f00b3?w=800&q=80', category_id=rings.id),
        Product(name='Emerald Halo Ring', description='Emerald center stone with diamond halo.',
                price_cents=99999, stock=5, image_url='https://images.unsplash.com/photo-1542382257-80dedb725088?w=800&q=80', category_id=rings.id),
        Product(name='Gold Link Bracelet', description='18k gold classic link bracelet.',
                price_cents=45999, stock=15, image_url='https://images.unsplash.com/photo-1617038260897-5d64fa6a43a1?w=800&q=80', category_id=bracelets.id),
        Product(name='Pearl Necklace', description='Cultured pearls with sterling clasp.',
                price_cents=34999, stock=20, image_url='https://images.unsplash.com/photo-1599643477877-530eb83abc5b?w=800&q=80', category_id=necklaces.id),
        Product(name='Sapphire Stud Earrings', description='Brilliant-cut sapphires in white gold.',
                price_cents=28999, stock=25, image_url='https://images.unsplash.com/photo-1585384459984-a4155223163f?w=800&q=80', category_id=earrings.id),
        Product(name='Rose Gold Pendant', description='Minimalist pendant in rose gold.',
                price_cents=18999, stock=18, image_url='https://images.unsplash.com/photo-1612815154858-60aa4c59eaa2?w=800&q=80', category_id=necklaces.id),
    ]
    db.session.add_all(products)
    db.session.commit()
    print('Database initialized. Admin: admin@charlottejewellers.com / admin123')

if __name__ == '__main__':
    run()